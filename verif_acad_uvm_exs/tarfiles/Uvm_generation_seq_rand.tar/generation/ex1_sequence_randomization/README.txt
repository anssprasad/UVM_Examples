This example shows how to use randomized variables within a sequence to control
how the sequence works during generation.

To compile and run the simulation, please use the make file:

make all - Compile and run
make build - Compile only
make sim  - Run the simulation in command line mode

The Makefile assumes the use of Questa 10.0b or a later version with
built-in support for UVM
