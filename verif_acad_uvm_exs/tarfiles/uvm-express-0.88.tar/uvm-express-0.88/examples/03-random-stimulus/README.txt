
Simple SystemVerilog interface, with tasks.
Simple DUT.
Functional Coverage
UVM/Agent based stimulus generation

