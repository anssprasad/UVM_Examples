
Simple SystemVerilog interface, with tasks.
Simple DUT.

